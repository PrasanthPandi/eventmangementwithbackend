
const express= require('express');
const mongoose=require('mongoose');

const app=express();

const product

app.listen(8000,()=>{
    console.log(`Server started at localhost:5000`);
})



